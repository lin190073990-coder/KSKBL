plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.qingping.adblock"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.qingping.adblock"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "1.2.0"
    }

    // full：带 OCR（Google ML Kit 中文识别，本机运行），安装包更大，ML Kit 会带入联网权限。
    // lite：不含 OCR，没有联网权限。两个版本包名相同，互相覆盖安装即可切换。
    flavorDimensions += "edition"
    productFlavors {
        create("full") {
            dimension = "edition"
            ndk {
                abiFilters.add("arm64-v8a") // 只打 64 位，避免 ML Kit 的模型库把包撑得更大
            }
        }
        create("lite") {
            dimension = "edition"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    add("fullImplementation", "com.google.mlkit:text-recognition-chinese:16.0.1")
}
