package com.qingping.adblock

import android.graphics.Bitmap

/** lite 版：不含 OCR，也就没有 ML Kit 带来的联网权限。 */
object OcrEngine {
    const val available = false

    fun recognize(bmp: Bitmap, done: (List<OcrLine>) -> Unit) {
        done(emptyList())
    }
}
