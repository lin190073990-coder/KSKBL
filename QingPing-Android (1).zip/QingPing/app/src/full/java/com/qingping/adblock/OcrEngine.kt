package com.qingping.adblock

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions

/**
 * full 版：用 Google ML Kit 的中文文字识别（模型打包在安装包里，在本机运行，截图不保存、不上传）。
 * lite 版里同名的 OcrEngine 是空实现，见 src/lite。
 */
object OcrEngine {
    const val available = true

    private val recognizer by lazy {
        TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    }

    /** done 在主线程回调；任何失败都回调空列表。 */
    fun recognize(bmp: Bitmap, done: (List<OcrLine>) -> Unit) {
        try {
            recognizer.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { text ->
                    val out = ArrayList<OcrLine>()
                    for (block in text.textBlocks) {
                        for (line in block.lines) {
                            val box = line.boundingBox ?: continue
                            out.add(OcrLine(line.text, box))
                        }
                    }
                    done(out)
                }
                .addOnFailureListener { done(emptyList()) }
        } catch (e: Throwable) {
            done(emptyList())
        }
    }
}
