package com.qingping.adblock

import android.graphics.Rect

/** OCR 识别出的一行文字，box 是它在截图里的位置（像素）。 */
class OcrLine(val text: String, val box: Rect)
