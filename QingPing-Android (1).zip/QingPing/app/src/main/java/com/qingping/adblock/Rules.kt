package com.qingping.adblock

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/** 一次命中：why 写进记录便于排查；sig 是“这个控件”的稳定签名，用来做“不再点这个”。 */
class Match(val why: String, val sig: String)

/**
 * 所有“识别规则”集中在这里。广告 SDK 改版、遇到新的广告样式时，只需要改这个文件。
 * 类名和控件 ID 会随 SDK 版本变化，下面的列表是常见写法，不保证覆盖所有版本。
 */
object Rules {

    // ---------- 开屏“跳过”按钮 ----------

    // 去掉空白、分隔符、括号、箭头之后再匹配，所以 “跳过 | 3s”“3S 跳过”“Skip Ads” 都能命中
    private val SEPARATORS = Regex("[\\s|丨·:：\\-—>＞»›()（）\\[\\]【】<《》]")

    private val SKIP_TEXT = Regex(
        "^(?:" +
            "(?:\\d{1,2}[s秒]?)?(?:点击|點擊)?(?:跳过|跳過|skip)(?:广告|廣告|ads?)?(?:\\d{1,2}[s秒]?)?" +
            "|关闭广告|關閉廣告" +
            ")$"
    )

    private val ID_AD_TOKENS =
        setOf("splash", "ad", "ads", "ksad", "tt", "gdt", "bd", "adv", "advert", "launch")
    private val ID_EXACT =
        setOf("tv_skip", "btn_skip", "skip_btn", "skip_view", "iv_skip", "ll_skip")

    private fun norm(s: CharSequence?): String =
        s?.toString()?.lowercase()?.replace(SEPARATORS, "") ?: ""

    private val DIGITS = Regex("\\d+")

    /** 文字的稳定签名：去分隔符、转小写、数字换成 #，这样“3s 跳过”和“2s 跳过”是同一个签名。 */
    fun sigText(s: CharSequence?): String = norm(s).replace(DIGITS, "#")

    /** 一段文字（比如 OCR 识别出来的）像不像“跳过”。 */
    fun isSkipText(raw: CharSequence?): Boolean {
        val t = norm(raw)
        return t.isNotEmpty() && t.length <= 14 && SKIP_TEXT.matches(t)
    }

    /** 命中返回命中信息（原因 + 签名），没命中返回 null。 */
    fun matchSkip(n: AccessibilityNodeInfo, maxDim: Int): Match? {
        // 太大的容器不可能是“跳过”按钮，直接排除，避免点到整屏
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty || r.height() > maxDim * 0.2 || r.width() > maxDim * 0.5) return null

        val t = norm(n.text)
        if (t.isNotEmpty() && t.length <= 14 && SKIP_TEXT.matches(t)) {
            return Match("text=" + n.text, "text:" + sigText(n.text))
        }
        val d = norm(n.contentDescription)
        if (d.isNotEmpty() && d.length <= 14 && SKIP_TEXT.matches(d)) {
            return Match("desc=" + n.contentDescription, "desc:" + sigText(n.contentDescription))
        }

        val id = n.viewIdResourceName ?: return null
        val tail = id.substringAfterLast('/').lowercase()
        if (tail in ID_EXACT) return Match("id=$tail", "id:$tail")
        val tokens = tail.split('_', '-')
        if ("skip" in tokens && tokens.any { it in ID_AD_TOKENS }) return Match("id=$tail", "id:$tail")
        return null
    }

    // ---------- 广告落地页（应用内） ----------

    private val LANDING_EXACT = setOf(
        "com.qq.e.ads.ADActivity",
        "com.qq.e.ads.PortraitADActivity",
        "com.qq.e.ads.LandscapeADActivity",
        "com.baidu.mobads.sdk.api.AppActivity",
        "com.baidu.mobads.AppActivity"
    )
    private val LANDING_PARTS = listOf(
        "TTLandingPageActivity",
        "TTPlayableLandingPageActivity",
        "TTVideoLandingPageActivity",
        "AdLandingPageActivity",
        "AdWebViewActivity"
    )

    /** 真正的 Activity 类名。悬浮窗、对话框常报 android.* 开头的通用类名，不能当作“被带去了别的应用”。 */
    fun looksLikeActivity(cls: String?): Boolean =
        cls != null && !cls.startsWith("android.") && !cls.startsWith("androidx.")

    fun isAdLanding(cls: String?): Boolean =
        cls != null && (cls in LANDING_EXACT || LANDING_PARTS.any { cls.contains(it) })

    // ---------- 广告常把你带去的“系统级”目的地（浏览器、应用商店） ----------
    // 普通第三方应用（淘宝、京东、拼多多……）不用列，服务里会按“用户安装的应用”判断。

    val JUMP_TARGETS = setOf(
        // 浏览器
        "com.android.chrome", "com.android.browser", "com.UCMobile", "com.tencent.mtt",
        "com.huawei.browser", "com.heytap.browser", "com.vivo.browser", "com.miui.browser",
        "com.mi.globalbrowser", "com.baidu.searchbox", "com.quark.browser",
        "com.sec.android.app.sbrowser",
        // 应用商店
        "com.android.vending", "com.huawei.appmarket", "com.xiaomi.market",
        "com.heytap.market", "com.oppo.market", "com.bbk.appstore", "com.hihonor.appmarket",
        "com.tencent.android.qqdownloader", "com.sec.android.app.samsungapps",
        // 广告常见的落地 App（电商、短视频、资讯）。只有这里列出的才会被“自动返回”，
        // VPN、工具、系统组件、悬浮窗等出现在前台时，清屏不会再替你按返回。
        "com.taobao.taobao", "com.tmall.wireless", "com.taobao.idlefish",
        "com.jingdong.app.mall", "com.xunmeng.pinduoduo", "com.achievo.vipshop",
        "com.suning.mobile.ebuy", "com.sankuai.meituan", "me.ele",
        "com.ss.android.ugc.aweme", "com.ss.android.ugc.aweme.lite",
        "com.smile.gifmaker", "com.kuaishou.nebula", "com.ss.android.article.news",
        "com.xingin.xhs", "com.sina.weibo"
    )

    // ---------- 需要完全忽略的系统界面（权限弹窗、输入法、安装器等） ----------

    private val IGNORED = setOf("android", "com.android.settings", "com.google.android.setupwizard")
    private val NOISE_PARTS = listOf(
        "systemui", "permissioncontroller", "packageinstaller", "securitycenter", "safecenter",
        "lbe.security", "systemmanager", "securitypermission", "permissionmanager",
        "iqoo.secure", "setupwizard", "inputmethod"
    )

    fun isNoise(pkg: String): Boolean = pkg in IGNORED || NOISE_PARTS.any { pkg.contains(it) }

    // ---------- 弹窗广告的“关闭”按钮 ----------
    // 强信号：文字本身就是“关闭广告 / 以后再说”这类，或控件 ID 同时带“ad 类词”和“close”。
    // 弱信号：只是“关闭 / ×”，必须同一界面里出现“广告”标记才算，避免误点普通界面的“关闭”。

    private val POPUP_STRONG_TEXT = setOf(
        "关闭广告", "广告关闭", "關閉廣告", "以后再说", "稍后再说", "下次再说",
        "暂不升级", "暂不更新", "暂不开启", "暂时不用", "残忍拒绝"
    )
    private val POPUP_WEAK_TEXT = setOf("关闭", "×", "✕", "✖", "╳", "✗", "x", "close")
    private val POPUP_AD_TOKENS =
        setOf("ad", "ads", "ksad", "tt", "gdt", "adv", "advert", "interstitial", "insert")
    private val AD_MARKERS = setOf("广告", "ad", "ads", "advertisement")
    private val NOT_BUTTON_CLASS = listOf("Switch", "CheckBox", "Toggle", "EditText", "Radio")

    private fun smallEnough(n: AccessibilityNodeInfo, maxDim: Int): Boolean {
        val r = Rect()
        n.getBoundsInScreen(r)
        return !r.isEmpty && r.height() <= maxDim * 0.2 && r.width() <= maxDim * 0.5
    }

    /** 界面里有没有“广告”两个字的小标签。 */
    fun isAdMarker(n: AccessibilityNodeInfo): Boolean {
        val t = norm(n.text)
        if (t.isNotEmpty() && t in AD_MARKERS) return true
        val d = norm(n.contentDescription)
        return d.isNotEmpty() && d in AD_MARKERS
    }

    fun matchPopupStrong(n: AccessibilityNodeInfo, maxDim: Int): Match? {
        if (!smallEnough(n, maxDim)) return null
        val t = norm(n.text)
        if (t.isNotEmpty() && t in POPUP_STRONG_TEXT) {
            return Match("弹窗 text=" + n.text, "text:" + sigText(n.text))
        }
        val d = norm(n.contentDescription)
        if (d.isNotEmpty() && d in POPUP_STRONG_TEXT) {
            return Match("弹窗 desc=" + n.contentDescription, "desc:" + sigText(n.contentDescription))
        }
        val id = n.viewIdResourceName ?: return null
        val tail = id.substringAfterLast('/').lowercase()
        val tokens = tail.split('_', '-')
        if (("close" in tokens && tokens.any { it in POPUP_AD_TOKENS }) ||
            tail.contains("adclose") || tail.contains("closead")
        ) return Match("弹窗 id=$tail", "id:$tail")
        return null
    }

    fun matchPopupWeak(n: AccessibilityNodeInfo, maxDim: Int): Match? {
        if (n.isCheckable || !smallEnough(n, maxDim)) return null
        val cls = n.className?.toString().orEmpty()
        if (NOT_BUTTON_CLASS.any { cls.contains(it) }) return null
        val t = norm(n.text)
        if (t.isNotEmpty() && t in POPUP_WEAK_TEXT) {
            return Match("弹窗 text=" + n.text, "text:" + sigText(n.text))
        }
        val d = norm(n.contentDescription)
        if (d.isNotEmpty() && d in POPUP_WEAK_TEXT) {
            return Match("弹窗 desc=" + n.contentDescription, "desc:" + sigText(n.contentDescription))
        }
        return null
    }

    // ---------- 安全保护：银行、支付、钱包、密码管理类应用，一律不自动点 ----------

    private val SENSITIVE_EXACT = setOf(
        "com.eg.android.AlipayGphone", "com.unionpay", "cmb.pb", "com.icbc",
        "com.chinamworld.main", "com.chinamworld.bocmbci", "com.android.bankabc",
        "com.bankcomm.Bankcomm", "com.yitong.mbank.psbc", "com.tencent.mm.wallet",
        "com.google.android.apps.walletnfcrel", "com.paypal.android.p2pmobile"
    )
    private val SENSITIVE_TOKENS = listOf(
        "bank", "alipay", "unionpay", "wallet", "paypal", "authenticator",
        "keepass", "bitwarden", "onepassword", "lastpass"
    )

    fun isSensitivePkg(pkg: String): Boolean {
        if (pkg in SENSITIVE_EXACT) return true
        val l = pkg.lowercase()
        return SENSITIVE_TOKENS.any { l.contains(it) }
    }
}
