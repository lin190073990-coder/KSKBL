package com.qingping.adblock

import android.content.Context
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * 用户自定义规则：针对某个应用（可再限定到某个界面），按文字 / 正则 / 控件 ID / 坐标点一下。
 * 还可以带两个高级选项：
 *   - 条件：界面里同时出现某段文字时才点；
 *   - 后续步骤：第一下点成功后，再依次点最多 3 个目标（比如“×”之后再点“不感兴趣”）。
 * 存在本机 SharedPreferences 里，可以复制成 JSON 导出、从剪贴板导入，全程不联网。
 */
object RuleStore {
    const val KIND_TEXT = "text"
    const val KIND_REGEX = "regex"
    const val KIND_ID = "id"
    const val KIND_XY = "xy"
    private val KINDS = setOf(KIND_TEXT, KIND_REGEX, KIND_ID, KIND_XY)
    const val MAX_STEPS = 3

    private const val FILE = "qingping_rules"
    private const val KEY = "rules"

    /** 后续步骤里的一步。 */
    data class Step(val kind: String, val value: String)

    data class Rule(
        val id: String,
        val pkg: String,
        val activity: String,   // 空 = 该应用所有界面
        val kind: String,
        val value: String,
        val note: String,
        val enabled: Boolean,
        val whenText: String = "",              // 空 = 无条件
        val steps: List<Step> = emptyList()     // 空 = 点完就结束
    ) {
        fun summary(): String = buildString {
            append(RuleStore.kindWord(kind)).append("  ").append(value)
            if (whenText.isNotEmpty()) append("\n条件：界面出现「").append(whenText).append("」")
            for ((i, st) in steps.withIndex()) {
                append("\n第 ").append(i + 2).append(" 步：")
                append(RuleStore.kindWord(st.kind)).append("  ").append(st.value)
            }
        }

        /** 坐标规则：屏幕宽高的比例，0~1。 */
        fun xy(): Pair<Float, Float>? = if (kind == RuleStore.KIND_XY) RuleStore.parseXy(value) else null

        val delayMs: Long get() = 800L
    }

    @Volatile
    private var cache: List<Rule>? = null
    private val regexCache = ConcurrentHashMap<String, Regex>()

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun newId(): String = java.util.UUID.randomUUID().toString().take(8)

    fun kindWord(kind: String): String = when (kind) {
        KIND_ID -> "控件ID"
        KIND_TEXT -> "文字"
        KIND_REGEX -> "正则"
        else -> "坐标"
    }

    fun parseXy(v: String): Pair<Float, Float>? {
        val p = v.split(',')
        if (p.size != 2) return null
        val x = p[0].trim().toFloatOrNull()
        val y = p[1].trim().toFloatOrNull()
        if (x == null || y == null || x !in 0f..1f || y !in 0f..1f) return null
        return x to y
    }

    fun valid(kind: String, value: String): Boolean = when (kind) {
        KIND_XY -> parseXy(value) != null
        KIND_REGEX -> try {
            Regex(value)
            true
        } catch (e: Exception) {
            false
        }
        else -> value.isNotBlank()
    }

    // ------------------------------------------------------------------ 后续步骤的文字写法

    /** 每行一步，写法“类型:内容”，类型可写 文字 / 正则 / 控件ID / 坐标（或 text / regex / id / xy）。 */
    fun stepsToText(steps: List<Step>): String =
        steps.joinToString("\n") { kindWord(it.kind) + ":" + it.value }

    /** 空文本 = 没有后续步骤（返回空列表）；写法不对、步数超限返回 null。 */
    fun parseSteps(text: String): List<Step>? {
        val out = ArrayList<Step>()
        for (line in text.lines()) {
            val t = line.trim()
            if (t.isEmpty()) continue
            val idx = t.indexOfFirst { it == ':' || it == '：' }
            if (idx <= 0) return null
            val word = t.substring(0, idx).trim().lowercase()
            val value = t.substring(idx + 1).trim()
            val kind = when (word) {
                "text", "文字" -> KIND_TEXT
                "regex", "正则" -> KIND_REGEX
                "id", "控件id", "控件" -> KIND_ID
                "xy", "坐标" -> KIND_XY
                else -> return null
            }
            if (!valid(kind, value)) return null
            out.add(Step(kind, value))
        }
        if (out.size > MAX_STEPS) return null
        return out
    }

    // ------------------------------------------------------------------ 读写

    @Synchronized
    fun all(c: Context): List<Rule> {
        cache?.let { return it }
        val list = parse(sp(c).getString(KEY, null)) ?: emptyList()
        cache = list
        return list
    }

    @Synchronized
    private fun save(c: Context, list: List<Rule>) {
        sp(c).edit().putString(KEY, toJson(list)).apply()
        cache = list
    }

    private fun same(a: Rule, b: Rule) =
        a.pkg == b.pkg && a.activity == b.activity && a.kind == b.kind && a.value == b.value &&
            a.whenText == b.whenText && a.steps == b.steps

    /** 已有完全相同的规则时返回 false。 */
    fun add(c: Context, r: Rule): Boolean {
        val cur = all(c)
        if (cur.any { same(it, r) }) return false
        save(c, cur + r)
        return true
    }

    fun remove(c: Context, id: String) = save(c, all(c).filter { it.id != id })

    fun setEnabled(c: Context, id: String, on: Boolean) =
        save(c, all(c).map { if (it.id == id) it.copy(enabled = on) else it })

    fun updateExtras(c: Context, id: String, whenText: String, steps: List<Step>) =
        save(c, all(c).map { if (it.id == id) it.copy(whenText = whenText, steps = steps) else it })

    // ------------------------------------------------------------------ 导入导出

    fun exportJson(c: Context): String = toJson(all(c))

    /** 返回新增条数；JSON 格式不对返回 -1。 */
    fun importJson(c: Context, raw: String): Int {
        val incoming = parse(raw) ?: return -1
        var added = 0
        for (r in incoming) {
            if (add(c, r.copy(id = newId()))) added++
        }
        return added
    }

    private fun toJson(list: List<Rule>): String {
        val arr = JSONArray()
        for (r in list) {
            val steps = JSONArray()
            for (st in r.steps) steps.put(JSONObject().put("kind", st.kind).put("value", st.value))
            arr.put(
                JSONObject()
                    .put("id", r.id)
                    .put("pkg", r.pkg)
                    .put("activity", r.activity)
                    .put("kind", r.kind)
                    .put("value", r.value)
                    .put("note", r.note)
                    .put("enabled", r.enabled)
                    .put("when", r.whenText)
                    .put("steps", steps)
            )
        }
        return arr.toString(2)
    }

    /** JSON 本身有问题返回 null；单条不合格的规则直接丢掉。 */
    private fun parse(raw: String?): List<Rule>? {
        if (raw.isNullOrBlank()) return emptyList()
        val out = ArrayList<Rule>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val pkg = o.optString("pkg").trim()
                val kind = o.optString("kind").trim()
                val value = o.optString("value").trim()
                if (pkg.isEmpty() || kind !in KINDS || !valid(kind, value)) continue
                val steps = ArrayList<Step>()
                val sa = o.optJSONArray("steps")
                if (sa != null) {
                    for (j in 0 until sa.length()) {
                        val so = sa.optJSONObject(j) ?: continue
                        val sk = so.optString("kind").trim()
                        val sv = so.optString("value").trim()
                        if (sk in KINDS && valid(sk, sv) && steps.size < MAX_STEPS) steps.add(Step(sk, sv))
                    }
                }
                out.add(
                    Rule(
                        o.optString("id").ifBlank { newId() },
                        pkg,
                        o.optString("activity").trim(),
                        kind,
                        value,
                        o.optString("note"),
                        o.optBoolean("enabled", true),
                        o.optString("when").trim(),
                        steps
                    )
                )
            }
        } catch (e: Exception) {
            return null
        }
        return out
    }

    // ------------------------------------------------------------------ 供服务使用

    /** 当前应用 / 界面下需要“找控件”的规则（不含坐标规则）。 */
    fun forScan(c: Context, pkg: String, cls: String?): List<Rule> =
        all(c).filter {
            it.enabled && it.kind != KIND_XY && it.pkg == pkg &&
                (it.activity.isEmpty() || it.activity == cls)
        }

    fun xyFor(c: Context, pkg: String, cls: String?): List<Rule> =
        all(c).filter {
            it.enabled && it.kind == KIND_XY && it.pkg == pkg &&
                (it.activity.isEmpty() || it.activity == cls)
        }

    private fun nodeMatches(kind: String, value: String, text: String, desc: String, id: String): Boolean =
        when (kind) {
            KIND_ID -> id.isNotEmpty() && (id == value || id.substringAfterLast('/') == value)
            KIND_TEXT -> (text.isNotEmpty() && text == value) || (desc.isNotEmpty() && desc == value)
            KIND_REGEX -> {
                val re = regexCache.getOrPut(value) { Regex(value) }
                (text.isNotEmpty() && re.matches(text)) || (desc.isNotEmpty() && re.matches(desc))
            }
            else -> false
        }

    /** 这个节点命中了哪些规则（条件由调用方另行判断）。 */
    fun matching(rules: List<Rule>, n: AccessibilityNodeInfo): List<Rule> {
        if (rules.isEmpty()) return emptyList()
        val text = n.text?.toString()?.trim().orEmpty()
        val desc = n.contentDescription?.toString()?.trim().orEmpty()
        val id = n.viewIdResourceName.orEmpty()
        var out: ArrayList<Rule>? = null
        for (r in rules) {
            if (nodeMatches(r.kind, r.value, text, desc, id)) {
                if (out == null) out = ArrayList()
                out.add(r)
            }
        }
        return out ?: emptyList()
    }

    fun matchStep(kind: String, value: String, n: AccessibilityNodeInfo): Boolean {
        val text = n.text?.toString()?.trim().orEmpty()
        val desc = n.contentDescription?.toString()?.trim().orEmpty()
        val id = n.viewIdResourceName.orEmpty()
        return nodeMatches(kind, value, text, desc, id)
    }
}
