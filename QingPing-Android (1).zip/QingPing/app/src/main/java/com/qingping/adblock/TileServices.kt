package com.qingping.adblock

import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

/** 下拉通知栏里的“清屏捕捉”：一点就显示悬浮按钮，不用先进应用。 */
class CaptureTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        val svc = AdSkipService.instance
        if (svc == null) {
            Toast.makeText(this, "请先在清屏里开启无障碍服务", Toast.LENGTH_LONG).show()
            return
        }
        if (svc.isCapturing()) {
            svc.stopCapture()
        } else {
            svc.startCapture()
            svc.collapseShade()
        }
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        val on = AdSkipService.instance?.isCapturing() == true
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = if (on) "捕捉中" else "清屏捕捉"
        t.updateTile()
    }
}

/** 下拉通知栏里的“暂停清屏”：点一下暂停 30 分钟，再点恢复。 */
class PauseTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        if (Prefs.isPaused(this)) Prefs.resume(this) else Prefs.pauseFor(this, 30 * 60_000L)
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        val paused = Prefs.isPaused(this)
        t.state = if (paused) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = if (paused) "清屏已暂停" else "暂停清屏"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val left = ((Prefs.pausedUntil(this) - System.currentTimeMillis()) / 60_000L).coerceAtLeast(0L) + 1
            t.subtitle = if (paused) "剩余约 $left 分钟" else "点一下暂停 30 分钟"
        }
        t.updateTile()
    }
}
