package com.qingping.adblock

import android.content.ClipData
import android.content.ClipboardManager
import android.content.DialogInterface
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.materialswitch.MaterialSwitch

/** 自定义规则的管理页：捕捉、手动添加、启用 / 停用 / 删除、编辑条件与步骤、导入导出、已屏蔽的控件。 */
class RulesActivity : AppCompatActivity() {

    private lateinit var list: LinearLayout
    private lateinit var tvEmpty: TextView
    private lateinit var listBlocked: LinearLayout
    private lateinit var tvBlockedEmpty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rules)
        list = findViewById(R.id.list)
        tvEmpty = findViewById(R.id.tvEmpty)
        listBlocked = findViewById(R.id.listBlocked)
        tvBlockedEmpty = findViewById(R.id.tvBlockedEmpty)

        findViewById<View>(R.id.btnCapture).setOnClickListener { startCapture() }
        findViewById<View>(R.id.btnAdd).setOnClickListener { pickApp() }
        findViewById<View>(R.id.btnExport).setOnClickListener { exportRules() }
        findViewById<View>(R.id.btnImport).setOnClickListener { importRules() }
    }

    override fun onResume() {
        super.onResume()
        render()
        renderBlocked()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------------------ 规则列表

    private fun render() {
        list.removeAllViews()
        val rules = RuleStore.all(this)
        tvEmpty.visibility = if (rules.isEmpty()) View.VISIBLE else View.GONE
        for (r in rules) {
            val row = layoutInflater.inflate(R.layout.item_rule, list, false)
            val (label, icon) = labelAndIcon(r.pkg)
            row.findViewById<TextView>(R.id.tvName).text = label
            row.findViewById<TextView>(R.id.tvDetail).text = buildString {
                append(r.summary())
                if (r.activity.isNotEmpty()) append("\n界面 ").append(r.activity.substringAfterLast('.'))
            }
            row.findViewById<ImageView>(R.id.ivIcon).setImageDrawable(icon)
            row.findViewById<MaterialSwitch>(R.id.swOn).apply {
                isChecked = r.enabled
                setOnCheckedChangeListener { _, on -> RuleStore.setEnabled(this@RulesActivity, r.id, on) }
            }
            row.setOnClickListener { showRule(r, label) }
            list.addView(row)
        }
    }

    private fun labelAndIcon(pkg: String): Pair<String, Drawable?> = try {
        val ai = packageManager.getApplicationInfo(pkg, 0)
        packageManager.getApplicationLabel(ai).toString() to packageManager.getApplicationIcon(ai)
    } catch (e: Exception) {
        pkg to null // 应用已卸载，显示包名
    }

    private fun showRule(r: RuleStore.Rule, label: String) {
        AlertDialog.Builder(this)
            .setTitle(label)
            .setMessage(
                buildString {
                    append(r.summary())
                    append("\n\n包名  ").append(r.pkg)
                    append("\n界面  ").append(r.activity.ifEmpty { "该应用所有界面" })
                }
            )
            .setPositiveButton("关闭", null)
            .setNegativeButton("删除") { _, _ ->
                RuleStore.remove(this, r.id)
                render()
            }
            .setNeutralButton("编辑条件与步骤") { _, _ -> showExtras(r, label) }
            .show()
    }

    private fun showExtras(r: RuleStore.Rule, label: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val extras = RuleExtras(this, r.whenText, RuleStore.stepsToText(r.steps))
        extras.addTo(box)
        val sv = ScrollView(this).apply { addView(box) }
        val dlg = AlertDialog.Builder(this)
            .setTitle("编辑：$label")
            .setView(sv)
            .setPositiveButton("保存", null)
            .setNegativeButton("取消", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val steps = extras.steps()
                if (steps == null) {
                    toast(RuleExtras.STEPS_ERROR)
                } else {
                    RuleStore.updateExtras(this, r.id, extras.whenText(), steps)
                    render()
                    dlg.dismiss()
                }
            }
        }
        dlg.show()
    }

    // ------------------------------------------------------------------ 已屏蔽的控件

    private fun renderBlocked() {
        listBlocked.removeAllViews()
        val blocks = BlockStore.all(this)
        tvBlockedEmpty.visibility = if (blocks.isEmpty()) View.VISIBLE else View.GONE
        for (b in blocks) {
            val row = layoutInflater.inflate(R.layout.item_node, listBlocked, false)
            val label = labelAndIcon(b.pkg).first
            row.findViewById<TextView>(R.id.tvName).text = label
            row.findViewById<TextView>(R.id.tvDetail).text = BlockStore.describe(b.sig)
            row.setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle("恢复自动点击？")
                    .setMessage("$label：${BlockStore.describe(b.sig)}\n恢复后，清屏又会自动点它。")
                    .setPositiveButton("恢复") { _, _ ->
                        BlockStore.remove(this, b.pkg, b.sig)
                        renderBlocked()
                    }
                    .setNegativeButton("取消", null)
                    .show()
            }
            listBlocked.addView(row)
        }
    }

    // ------------------------------------------------------------------ 捕捉

    private fun startCapture() {
        val svc = AdSkipService.instance
        if (svc == null) {
            toast("请先开启无障碍服务")
            return
        }
        svc.startCapture()
        toast("屏幕边缘出现了“捕捉当前界面”按钮。打开目标应用，广告出现时点它。捕捉期间清屏暂停自动点击。")
        moveTaskToBack(true)
    }

    // ------------------------------------------------------------------ 手动添加

    @Suppress("DEPRECATION")
    private fun pickApp() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second }
        if (apps.isEmpty()) {
            toast("没有找到可选的应用")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("选择应用")
            .setItems(apps.map { it.second }.toTypedArray()) { _, i ->
                showForm(apps[i].first, apps[i].second)
            }
            .show()
    }

    private fun showForm(pkg: String, label: String) {
        val kinds = listOf(
            RuleStore.KIND_TEXT to "按文字（完全相同）",
            RuleStore.KIND_REGEX to "按文字（正则，适合带倒计时数字的）",
            RuleStore.KIND_ID to "按控件 ID",
            RuleStore.KIND_XY to "按坐标（x,y 为 0~1 的屏幕比例，如 0.9,0.08）"
        )
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val group = RadioGroup(this)
        kinds.forEachIndexed { i, k ->
            group.addView(RadioButton(this).apply {
                id = 1000 + i
                text = k.second
                isChecked = i == 0
            })
        }
        val etValue = EditText(this).apply {
            hint = "内容，如：跳过"
            setSingleLine()
        }
        val etActivity = EditText(this).apply {
            hint = "界面类名（可留空：该应用所有界面都生效）"
            setSingleLine()
        }
        val extras = RuleExtras(this)
        box.addView(group)
        box.addView(etValue)
        box.addView(etActivity)
        extras.addTo(box)
        val sv = ScrollView(this).apply { addView(box) }

        val dlg = AlertDialog.Builder(this)
            .setTitle("新规则：$label")
            .setView(sv)
            .setPositiveButton("保存", null)
            .setNegativeButton("取消", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val kind = kinds[(group.checkedRadioButtonId - 1000).coerceIn(0, kinds.lastIndex)].first
                val value = etValue.text.toString().trim()
                val steps = extras.steps()
                when {
                    !RuleStore.valid(kind, value) -> toast("内容为空或格式不对，没有保存")
                    steps == null -> toast(RuleExtras.STEPS_ERROR)
                    else -> {
                        val rule = RuleStore.Rule(
                            RuleStore.newId(), pkg, etActivity.text.toString().trim(),
                            kind, value, "", true, extras.whenText(), steps
                        )
                        if (!RuleStore.add(this, rule)) toast("已经有相同的规则了")
                        render()
                        dlg.dismiss()
                    }
                }
            }
        }
        dlg.show()
    }

    // ------------------------------------------------------------------ 导入导出

    private fun exportRules() {
        val rules = RuleStore.all(this)
        if (rules.isEmpty()) {
            toast("还没有规则可导出")
            return
        }
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("qingping-rules", RuleStore.exportJson(this)))
        toast("已复制 ${rules.size} 条规则，可以粘贴发给朋友或存起来")
    }

    private fun importRules() {
        val cm = getSystemService(ClipboardManager::class.java)
        val clip = cm.primaryClip
        val raw = if (clip != null && clip.itemCount > 0) {
            clip.getItemAt(0).coerceToText(this)?.toString().orEmpty()
        } else ""
        if (raw.isBlank()) {
            toast("剪贴板是空的")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("导入规则")
            .setMessage("规则会让清屏在指定应用里自动点按钮。只导入你信任的人给你的规则。\n\n继续导入剪贴板里的内容？")
            .setPositiveButton("导入") { _, _ ->
                val n = RuleStore.importJson(this, raw)
                toast(
                    when {
                        n < 0 -> "剪贴板里不是有效的规则 JSON"
                        n == 0 -> "没有新规则（可能都已存在）"
                        else -> "已导入 $n 条规则"
                    }
                )
                render()
            }
            .setNegativeButton("取消", null)
            .show()
    }
}
