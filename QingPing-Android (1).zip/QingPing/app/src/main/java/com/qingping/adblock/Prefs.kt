package com.qingping.adblock

import android.content.Context

/** 轻量设置：功能开关、暂停计时、“暂停拦截”的应用名单、OCR 应用名单、服务是否连接过。 */
object Prefs {
    private const val FILE = "qingping_prefs"
    private const val K_SKIP = "skip_splash"
    private const val K_REDIRECT = "block_redirect"
    private const val K_POPUP = "close_popup"
    private const val K_SAFE = "safe_mode"
    private const val K_OCR = "ocr_enabled"
    private const val K_OCR_APPS = "ocr_pkgs"
    private const val K_PAUSE = "pause_until"
    private const val K_EXCLUDED = "excluded_pkgs"
    private const val K_EVER = "ever_connected"

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun skipSplash(c: Context) = sp(c).getBoolean(K_SKIP, true)
    fun setSkipSplash(c: Context, on: Boolean) = sp(c).edit().putBoolean(K_SKIP, on).apply()

    fun blockRedirect(c: Context) = sp(c).getBoolean(K_REDIRECT, true)
    fun setBlockRedirect(c: Context, on: Boolean) =
        sp(c).edit().putBoolean(K_REDIRECT, on).apply()

    fun popupClose(c: Context) = sp(c).getBoolean(K_POPUP, true)
    fun setPopupClose(c: Context, on: Boolean) = sp(c).edit().putBoolean(K_POPUP, on).apply()

    /** 安全保护：密码界面、银行 / 支付类应用不自动点击。默认开启。 */
    fun safeMode(c: Context) = sp(c).getBoolean(K_SAFE, true)
    fun setSafeMode(c: Context, on: Boolean) = sp(c).edit().putBoolean(K_SAFE, on).apply()

    /** OCR 兜底：默认关闭，且只对名单里的应用生效。 */
    fun ocrEnabled(c: Context) = sp(c).getBoolean(K_OCR, false)
    fun setOcrEnabled(c: Context, on: Boolean) = sp(c).edit().putBoolean(K_OCR, on).apply()

    fun ocrApps(c: Context): Set<String> = sp(c).getStringSet(K_OCR_APPS, null) ?: emptySet()
    fun setOcrApps(c: Context, pkgs: Set<String>) =
        sp(c).edit().putStringSet(K_OCR_APPS, HashSet(pkgs)).apply()

    /** 临时暂停：到这个时间点（系统时钟毫秒）之前，所有自动点击都停止。 */
    fun pausedUntil(c: Context): Long = sp(c).getLong(K_PAUSE, 0L)
    fun isPaused(c: Context): Boolean = System.currentTimeMillis() < pausedUntil(c)
    fun pauseFor(c: Context, ms: Long) =
        sp(c).edit().putLong(K_PAUSE, System.currentTimeMillis() + ms).apply()
    fun resume(c: Context) = sp(c).edit().putLong(K_PAUSE, 0L).apply()

    /** 至少有一个功能开关是开的（不管有没有处在暂停里）。 */
    fun anyFeatureOn(c: Context) = skipSplash(c) || blockRedirect(c) || popupClose(c)

    /** 现在是不是应该干活：有功能开着，并且没在暂停。 */
    fun anyEnabled(c: Context) = !isPaused(c) && anyFeatureOn(c)

    /** 服务至少连接成功过一次。没连接过就掉线提醒，会在你从没开启过的时候打扰你。 */
    fun everConnected(c: Context) = sp(c).getBoolean(K_EVER, false)
    fun markConnected(c: Context) = sp(c).edit().putBoolean(K_EVER, true).apply()

    fun excluded(c: Context): Set<String> = sp(c).getStringSet(K_EXCLUDED, null) ?: emptySet()

    fun setExcluded(c: Context, pkg: String, on: Boolean) {
        val copy = HashSet(excluded(c)) // getStringSet 返回的集合不能直接修改
        if (on) copy.add(pkg) else copy.remove(pkg)
        sp(c).edit().putStringSet(K_EXCLUDED, copy).apply()
    }
}
