package com.qingping.adblock

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi

/**
 * 清屏核心：
 *  1) 应用切入前台后的 SPLASH_WATCH_MS 内，轮询控件树，找到“跳过”并点击；
 *  2) 每次出现新界面 / 新弹窗后的 POPUP_WATCH_MS 内，找弹窗广告的“关闭”并点击（只对第三方应用）；
 *  3) 用户自定义规则（文字 / 正则 / 控件 ID / 坐标，可带条件和后续步骤），在对应应用里随时生效，
 *     每次界面变化最多触发一次；
 *  4) 从桌面启动应用后的 REDIRECT_WINDOW_MS 内，如果被广告带去了已知的广告落地应用或落地页，自动“返回”；
 *  5) OCR 兜底（可选）：读不到控件的界面，截屏后在本机识别“跳过”；
 *  6) 捕捉模式：显示一个悬浮按钮，把当前界面的控件抓下来，交给 CaptureActivity 生成规则。
 *
 * 安全保护（默认开）：界面里有密码框、或是银行 / 支付类应用时，一律不点、不返回。
 * “不再点这个”名单（BlockStore）里的控件不会被点。
 *
 * 全部在主线程执行；所有入口都包了 try/catch——无障碍服务一旦崩溃，系统会把它标记为“已崩溃”并停用。
 */
class AdSkipService : AccessibilityService() {

    companion object {
        private const val TAG = "Qingping"
        private const val DEBUG = true

        private const val SPLASH_WATCH_MS = 7_000L       // 切入应用后，多久内找“跳过”
        private const val POPUP_WATCH_MS = 10_000L       // 每次界面 / 弹窗出现后，多久内找“关闭”
        private const val REDIRECT_WINDOW_MS = 6_000L    // 从桌面启动应用后，多久内的跳转算广告跳转
        private const val REDIRECT_COOLDOWN_MS = 1_200L  // 两次“返回”的最小间隔，防止连按把应用退出
        private const val POLL_MS = 250L
        private const val MIN_SCAN_GAP_MS = 150L
        private const val ACTION_COOLDOWN_MS = 1_500L    // 任何一次点击之后的冷却
        private const val ENV_REFRESH_MS = 5 * 60_000L
        private const val MAX_NODES = 600
        private const val MAX_DEPTH = 40
        private const val MAX_BACK_RETRY = 2
        private const val CAPTURE_MAX_NODES = 1500

        private const val OCR_WATCH_MS = 6_000L          // 启动后多久内允许 OCR
        private const val OCR_GAP_MS = 900L              // 两次截屏的最小间隔（系统本身也限频）
        private const val OCR_MAX_ATTEMPTS = 4           // 每次打开应用最多截几次

        private const val STEP_FIRST_DELAY_MS = 350L     // 第一下点完后，等多久再找第二步
        private const val STEP_TIMEOUT_MS = 2_500L       // 每一步最多等多久

        /** 界面用它判断服务是否真的在运行（和“系统设置里已勾选”是两回事）。 */
        @Volatile
        var instance: AdSkipService? = null
    }

    private class Session(val pkg: String, val start: Long, val fromLauncher: Boolean) {
        var blockedUntil = 0L
        var ocrAttempts = 0
    }

    private class Hit(
        val node: AccessibilityNodeInfo,
        val why: String,
        val type: Int,
        val sig: String,
        val rule: RuleStore.Rule? = null
    )

    /** 多步规则的执行状态：依次找 steps 里的目标并点击。 */
    private class Chain(val pkg: String, val steps: List<RuleStore.Step>) {
        var idx = 0
        var deadline = 0L
        var busy = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var session: Session? = null
    private var currentPkg: String? = null
    private var currentClass: String? = null
    private var lastLauncherAt = 0L
    private var lastRedirectAt = 0L
    private var lastScanAt = 0L
    private var envAt = 0L
    private var popupUntil = 0L
    private val customFired = HashSet<String>()
    private var homes: Set<String> = emptySet()
    private var imes: Set<String> = emptySet()
    private val userAppCache = HashMap<String, Boolean>()

    private var chain: Chain? = null
    private var ocrBusy = false
    private var lastOcrAt = 0L

    private var captureView: View? = null
    private val capturing: Boolean get() = captureView != null

    // ------------------------------------------------------------------ 生命周期

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Prefs.markConnected(this)
        refreshEnv()
        Guard.clearNotification(this)
        Log.i(TAG, "service connected")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopCapture()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        stopCapture()
        instance = null
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onInterrupt() {}

    // ------------------------------------------------------------------ 给界面 / 下拉开关用

    fun isCapturing(): Boolean = capturing

    /** 收起下拉通知栏（Android 12+）。更早的系统上需要自己上划收起。 */
    fun collapseShade() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        }
    }

    // ------------------------------------------------------------------ 事件入口

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        try {
            if (capturing || !Prefs.anyEnabled(this)) return
            val pkg = event.packageName?.toString() ?: return
            when (event.eventType) {
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ->
                    onWindowChanged(pkg, event.className?.toString())
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> onContentChanged(pkg)
            }
        } catch (e: Throwable) {
            Log.w(TAG, "event failed", e)
        }
    }

    private fun onContentChanged(pkg: String) {
        val s = session ?: return
        if (pkg == s.pkg) scanFront(s, throttle = true)
    }

    private fun onWindowChanged(pkg: String, cls: String?) {
        val now = SystemClock.elapsedRealtime()
        if (now - envAt > ENV_REFRESH_MS) refreshEnv()

        // 桌面（包括放在桌面里的“最近任务”）
        if (pkg in homes) {
            lastLauncherAt = now
            currentPkg = pkg
            currentClass = cls
            return
        }
        // 自己、输入法、系统弹窗：完全忽略
        if (pkg == packageName || pkg in imes || Rules.isNoise(pkg)) return

        val prev = currentPkg
        currentPkg = pkg
        currentClass = cls
        if (DEBUG) Log.d(TAG, "window $pkg / $cls")

        // 新界面 / 新弹窗出现：重新开始找“关闭”，自定义规则也可以再触发一次
        popupUntil = now + POPUP_WATCH_MS
        customFired.clear()
        scheduleXyRules(pkg, cls)
        val s = session

        // 情况 A：还在同一个应用里。可能是广告落地页（如 GDT 的 ADActivity），也可能只是换了个界面 / 弹了个窗。
        if (s != null && s.pkg == pkg) {
            val landing = Prefs.blockRedirect(this) && !isExcluded(pkg) && !guarded(pkg) &&
                Rules.isAdLanding(cls) && now - s.start <= REDIRECT_WINDOW_MS &&
                !BlockStore.isBlocked(this, pkg, "redirect:" + cls)
            if (landing) {
                backFromAd(pkg, "落地页 $cls", "redirect:$cls") { currentClass == cls }
            } else {
                restartPoll()
            }
            return
        }

        // 情况 B：刚从桌面点开的应用，几秒内被带去了已知的广告落地应用（浏览器、应用商店、电商……）。
        // lastLauncherAt <= s.start 表示这期间没回过桌面，说明不是用户自己切换的。
        if (s != null && s.fromLauncher && lastLauncherAt <= s.start &&
            now - s.start <= REDIRECT_WINDOW_MS &&
            Prefs.blockRedirect(this) && !isExcluded(s.pkg) && !isExcluded(pkg) &&
            !guarded(s.pkg) && !guarded(pkg) &&
            isRedirectTarget(pkg) && Rules.looksLikeActivity(cls) &&
            !BlockStore.isBlocked(this, s.pkg, "redirect:$pkg")
        ) {
            backFromAd(s.pkg, "跳转到 $pkg", "redirect:$pkg") { currentPkg == pkg }
            return // 保持原会话不变
        }

        // 情况 C：新的应用切入前台，开启新会话
        session = Session(pkg, now, fromLauncher = prev != null && prev in homes)
        restartPoll()
    }

    private fun restartPoll() {
        main.removeCallbacks(poll)
        main.post(poll)
    }

    // ------------------------------------------------------------------ 扫描：跳过 / 关闭弹窗 / 自定义规则

    private val poll = object : Runnable {
        override fun run() {
            val s = session ?: return
            if (capturing) return
            val now = SystemClock.elapsedRealtime()
            if (now > maxOf(s.start + SPLASH_WATCH_MS, popupUntil)) return
            try {
                scanFront(s, throttle = false)
            } catch (e: Throwable) {
                Log.w(TAG, "poll failed", e)
            }
            main.postDelayed(this, POLL_MS)
        }
    }

    private fun scanFront(s: Session, throttle: Boolean) {
        if (capturing || !Prefs.anyEnabled(this)) return
        val now = SystemClock.elapsedRealtime()
        if (now < s.blockedUntil || isExcluded(s.pkg) || guarded(s.pkg)) return

        val wantSkip = Prefs.skipSplash(this) && now - s.start <= SPLASH_WATCH_MS
        val wantPopup = Prefs.popupClose(this) && now <= popupUntil &&
            userAppCache.getOrPut(s.pkg) { isUserApp(s.pkg) }
        val rules = RuleStore.forScan(this, s.pkg, currentClass).filter { it.id !in customFired }
        if (!wantSkip && !wantPopup && rules.isEmpty()) return
        if (throttle && now - lastScanAt < MIN_SCAN_GAP_MS) return
        lastScanAt = now

        val root = rootInActiveWindow
        if (root == null) {
            // 游戏 / 自绘界面有时读不到任何控件树，只能靠 OCR
            if (wantSkip) maybeOcr(s, now)
            return
        }
        try {
            if (root.packageName?.toString() != s.pkg) return
            val b = Rect()
            root.getBoundsInScreen(b)
            val dim = maxOf(b.width(), b.height()).takeIf { it > 0 }
                ?: resources.displayMetrics.heightPixels
            val hit = findHit(root, s.pkg, dim, wantSkip, wantPopup, rules)
            if (hit == null) {
                if (wantSkip) maybeOcr(s, now)
                return
            }
            s.blockedUntil = now + ACTION_COOLDOWN_MS
            // 安全保护：真要点之前才检查整棵树里有没有密码框，平时不增加开销
            if (Prefs.safeMode(this) && hasPasswordField(root)) {
                safeRecycle(hit.node)
                return
            }
            hit.rule?.let { customFired.add(it.id) }
            clickNode(hit.node) { ok ->
                if (ok) {
                    StatsStore.record(this, s.pkg, hit.type, hit.why, hit.sig)
                    Log.i(TAG, "hit: ${s.pkg} ${hit.why}")
                    hit.rule?.let { if (it.steps.isNotEmpty()) startChain(s.pkg, it.steps) }
                } else {
                    s.blockedUntil = 0L // 没点成功，允许下一轮重试
                    hit.rule?.let { customFired.remove(it.id) }
                }
                safeRecycle(hit.node)
            }
        } finally {
            safeRecycle(root)
        }
    }

    /**
     * 遍历一次控件树，按优先级返回：
     * 自定义规则（条件满足的）> 开屏“跳过” > 弹窗强信号 > 弹窗弱信号（需同界面有“广告”标记）。
     * “不再点这个”名单里的控件直接忽略。命中的节点不回收，由调用方用完后回收；其余节点这里统一回收。
     */
    private fun findHit(
        root: AccessibilityNodeInfo,
        pkg: String,
        maxDim: Int,
        wantSkip: Boolean,
        wantPopup: Boolean,
        rules: List<RuleStore.Rule>
    ): Hit? {
        val held = ArrayList<AccessibilityNodeInfo>()
        val cands = ArrayList<Pair<RuleStore.Rule, AccessibilityNodeInfo>>()
        // 带“条件”的规则：界面里要同时出现这些文字才算数
        val needles = rules.map { it.whenText.lowercase() }.filter { it.isNotEmpty() }.toSet()
        val found = HashSet<String>()
        val canStop = needles.isEmpty()
        var skip: Hit? = null
        var strong: Hit? = null
        var weak: Hit? = null
        var adMarker = false
        var visited = 0

        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (++visited > MAX_NODES || depth > MAX_DEPTH) return
            if (n.isVisibleToUser) {
                for (r in RuleStore.matching(rules, n)) cands.add(r to n)
                if (needles.isNotEmpty()) {
                    val t = n.text?.toString()?.lowercase().orEmpty()
                    val d = n.contentDescription?.toString()?.lowercase().orEmpty()
                    if (t.isNotEmpty() || d.isNotEmpty()) {
                        for (k in needles) {
                            if (t.contains(k) || d.contains(k)) found.add(k)
                        }
                    }
                }
                if (wantSkip && skip == null) {
                    val m = Rules.matchSkip(n, maxDim)
                    if (m != null && !BlockStore.isBlocked(this@AdSkipService, pkg, m.sig)) {
                        skip = Hit(n, m.why, StatsStore.TYPE_SPLASH, m.sig)
                    }
                }
                if (wantPopup) {
                    if (!adMarker && Rules.isAdMarker(n)) adMarker = true
                    if (strong == null) {
                        val m = Rules.matchPopupStrong(n, maxDim)
                        if (m != null && !BlockStore.isBlocked(this@AdSkipService, pkg, m.sig)) {
                            strong = Hit(n, m.why, StatsStore.TYPE_POPUP, m.sig)
                        }
                    }
                    if (weak == null) {
                        val m = Rules.matchPopupWeak(n, maxDim)
                        if (m != null && !BlockStore.isBlocked(this@AdSkipService, pkg, m.sig)) {
                            weak = Hit(n, m.why, StatsStore.TYPE_POPUP, m.sig)
                        }
                    }
                }
            }
            if (canStop && (cands.isNotEmpty() || skip != null)) return
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                held.add(c)
                walk(c, depth + 1)
                if (canStop && (cands.isNotEmpty() || skip != null)) return
            }
        }

        walk(root, 0)

        var custom: Hit? = null
        for ((r, node) in cands) {
            if (r.whenText.isEmpty() || r.whenText.lowercase() in found) {
                custom = Hit(node, "规则 " + r.summary().replace('\n', ' '), StatsStore.TYPE_RULE, "rule:" + r.id, r)
                break
            }
        }
        val chosen = custom ?: skip ?: strong ?: (if (adMarker) weak else null)
        for (h in held) {
            if (chosen == null || h !== chosen.node) safeRecycle(h)
        }
        return chosen
    }

    private fun hasPasswordField(root: AccessibilityNodeInfo): Boolean {
        var visited = 0
        fun walk(n: AccessibilityNodeInfo, depth: Int): Boolean {
            if (++visited > MAX_NODES || depth > MAX_DEPTH) return false
            if (n.isPassword) return true
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                val hit = walk(c, depth + 1)
                safeRecycle(c)
                if (hit) return true
            }
            return false
        }
        return walk(root, 0)
    }

    private fun screenHasPassword(): Boolean {
        val root = rootInActiveWindow ?: return false
        try {
            return hasPasswordField(root)
        } finally {
            safeRecycle(root)
        }
    }

    private fun guarded(pkg: String): Boolean = Prefs.safeMode(this) && Rules.isSensitivePkg(pkg)

    // ------------------------------------------------------------------ 点击

    private fun clickNode(node: AccessibilityNodeInfo, done: (Boolean) -> Unit) {
        // 1) 自己或最近的可点击祖先，直接触发点击
        var t: AccessibilityNodeInfo? = node
        var up = 0
        while (t != null && up <= 4) {
            if (t.isClickable && t.isEnabled && t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                done(true)
                return
            }
            t = t.parent
            up++
        }
        // 2) 没有可点击的控件（按钮靠 onTouch 实现的广告 SDK 很常见）：在中心位置模拟一次手指点击
        val r = Rect()
        node.getBoundsInScreen(r)
        if (r.isEmpty) {
            done(false)
            return
        }
        tap(r.exactCenterX(), r.exactCenterY(), done)
    }

    private fun tap(x: Float, y: Float, done: (Boolean) -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        val accepted = dispatchGesture(
            gesture,
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) = done(true)
                override fun onCancelled(gestureDescription: GestureDescription?) = done(false)
            },
            null
        )
        if (!accepted) done(false)
    }

    /** 坐标规则：进入对应界面后延迟一会儿，点一次。每次界面变化只点一次。 */
    private fun scheduleXyRules(pkg: String, cls: String?) {
        if (isExcluded(pkg) || guarded(pkg)) return
        for (r in RuleStore.xyFor(this, pkg, cls)) {
            main.postDelayed({
                try {
                    if (capturing || instance !== this || currentPkg != pkg) return@postDelayed
                    if (!Prefs.anyEnabled(this)) return@postDelayed
                    if (r.activity.isNotEmpty() && currentClass != r.activity) return@postDelayed
                    if (Prefs.safeMode(this) && screenHasPassword()) return@postDelayed
                    val p = r.xy() ?: return@postDelayed
                    val dm = resources.displayMetrics
                    tap(p.first * dm.widthPixels, p.second * dm.heightPixels) { ok ->
                        if (ok) {
                            StatsStore.record(
                                this, pkg, StatsStore.TYPE_RULE,
                                "规则 " + r.summary().replace('\n', ' '), "rule:" + r.id
                            )
                            if (r.steps.isNotEmpty()) startChain(pkg, r.steps)
                        }
                    }
                } catch (e: Throwable) {
                    Log.w(TAG, "xy rule failed", e)
                }
            }, r.delayMs)
        }
    }

    // ------------------------------------------------------------------ 多步规则

    private fun startChain(pkg: String, steps: List<RuleStore.Step>) {
        if (steps.isEmpty()) return
        val c = Chain(pkg, steps)
        c.deadline = SystemClock.elapsedRealtime() + STEP_FIRST_DELAY_MS + STEP_TIMEOUT_MS
        chain = c
        main.removeCallbacks(chainTick)
        main.postDelayed(chainTick, STEP_FIRST_DELAY_MS)
    }

    private val chainTick = object : Runnable {
        override fun run() {
            val c = chain ?: return
            try {
                if (capturing || !Prefs.anyEnabled(this@AdSkipService) || currentPkg != c.pkg) {
                    chain = null
                    return
                }
                if (SystemClock.elapsedRealtime() > c.deadline) {
                    chain = null
                    return
                }
                if (!c.busy) runChainStep(c)
            } catch (e: Throwable) {
                Log.w(TAG, "chain failed", e)
                chain = null
                return
            }
            if (chain === c) main.postDelayed(this, POLL_MS)
        }
    }

    private fun runChainStep(c: Chain) {
        val step = c.steps[c.idx]
        if (step.kind == RuleStore.KIND_XY) {
            val p = RuleStore.parseXy(step.value)
            if (p == null) {
                chain = null
                return
            }
            c.busy = true
            val dm = resources.displayMetrics
            tap(p.first * dm.widthPixels, p.second * dm.heightPixels) { ok -> afterStep(c, ok) }
            return
        }
        val root = rootInActiveWindow ?: return
        try {
            if (root.packageName?.toString() != c.pkg) return
            if (Prefs.safeMode(this) && hasPasswordField(root)) {
                chain = null
                return
            }
            val node = findStepNode(root, step) ?: return
            c.busy = true
            clickNode(node) { ok ->
                afterStep(c, ok)
                safeRecycle(node)
            }
        } finally {
            safeRecycle(root)
        }
    }

    private fun afterStep(c: Chain, ok: Boolean) {
        c.busy = false
        if (chain !== c || !ok) return // 没点成功就下一拍重试，直到超时
        c.idx++
        if (c.idx >= c.steps.size) {
            chain = null
        } else {
            c.deadline = SystemClock.elapsedRealtime() + STEP_TIMEOUT_MS
        }
    }

    private fun findStepNode(root: AccessibilityNodeInfo, step: RuleStore.Step): AccessibilityNodeInfo? {
        val held = ArrayList<AccessibilityNodeInfo>()
        var found: AccessibilityNodeInfo? = null
        var visited = 0

        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (found != null || ++visited > MAX_NODES || depth > MAX_DEPTH) return
            if (n.isVisibleToUser && RuleStore.matchStep(step.kind, step.value, n)) {
                found = n
                return
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                held.add(c)
                walk(c, depth + 1)
                if (found != null) return
            }
        }

        walk(root, 0)
        val f = found
        for (h in held) {
            if (f == null || h !== f) safeRecycle(h)
        }
        return f
    }

    // ------------------------------------------------------------------ OCR 兜底

    private fun maybeOcr(s: Session, now: Long) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R || !OcrEngine.available) return
        if (!Prefs.ocrEnabled(this) || s.pkg !in Prefs.ocrApps(this)) return
        if (ocrBusy || s.ocrAttempts >= OCR_MAX_ATTEMPTS) return
        if (now - s.start > OCR_WATCH_MS || now - lastOcrAt < OCR_GAP_MS) return
        ocrShot(s)
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun ocrShot(s: Session) {
        ocrBusy = true
        lastOcrAt = SystemClock.elapsedRealtime()
        s.ocrAttempts++
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                        val bmp: Bitmap? = try {
                            val hb = screenshot.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, screenshot.colorSpace)
                            val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            hw?.recycle()
                            hb.close()
                            soft
                        } catch (e: Throwable) {
                            Log.w(TAG, "screenshot decode failed", e)
                            null
                        }
                        if (bmp == null || instance !== this@AdSkipService || session !== s) {
                            bmp?.recycle()
                            ocrBusy = false
                            return
                        }
                        val bw = bmp.width
                        val bh = bmp.height
                        OcrEngine.recognize(bmp) { lines ->
                            ocrBusy = false
                            bmp.recycle()
                            try {
                                onOcrResult(s, lines, bw, bh)
                            } catch (e: Throwable) {
                                Log.w(TAG, "ocr result failed", e)
                            }
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        ocrBusy = false
                    }
                }
            )
        } catch (e: Throwable) {
            ocrBusy = false
            Log.w(TAG, "takeScreenshot failed", e)
        }
    }

    private fun onOcrResult(s: Session, lines: List<OcrLine>, bw: Int, bh: Int) {
        if (instance !== this || session !== s || currentPkg != s.pkg || capturing) return
        if (!Prefs.anyEnabled(this) || guarded(s.pkg) || bw <= 0 || bh <= 0) return
        val now = SystemClock.elapsedRealtime()
        if (now < s.blockedUntil) return
        for (l in lines) {
            if (!Rules.isSkipText(l.text)) continue
            val sig = "ocr:" + Rules.sigText(l.text)
            if (BlockStore.isBlocked(this, s.pkg, sig)) continue
            if (Prefs.safeMode(this) && screenHasPassword()) return
            val dm = resources.displayMetrics
            val x = l.box.exactCenterX() * dm.widthPixels / bw
            val y = l.box.exactCenterY() * dm.heightPixels / bh
            s.blockedUntil = now + ACTION_COOLDOWN_MS
            tap(x, y) { ok ->
                if (ok) {
                    StatsStore.record(this, s.pkg, StatsStore.TYPE_SPLASH, "OCR " + l.text, sig)
                    Log.i(TAG, "ocr hit: ${s.pkg} ${l.text}")
                } else {
                    s.blockedUntil = 0L
                }
            }
            return
        }
    }

    // ------------------------------------------------------------------ 误触跳转：自动返回

    private fun backFromAd(srcPkg: String, detail: String, sig: String, stillThere: () -> Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastRedirectAt < REDIRECT_COOLDOWN_MS) return
        lastRedirectAt = now
        performGlobalAction(GLOBAL_ACTION_BACK)
        StatsStore.record(this, srcPkg, StatsStore.TYPE_REDIRECT, detail, sig)
        Log.i(TAG, "redirect blocked: $srcPkg $detail")
        retryBack(1, stillThere)
    }

    /** 有些页面第一次返回会被拦截（比如弹“确定离开吗”），最多再按两次，且只有还停在广告页时才按。 */
    private fun retryBack(attempt: Int, stillThere: () -> Boolean) {
        if (attempt > MAX_BACK_RETRY) return
        main.postDelayed({
            try {
                if (instance === this && stillThere()) {
                    lastRedirectAt = SystemClock.elapsedRealtime()
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    retryBack(attempt + 1, stillThere)
                }
            } catch (e: Throwable) {
                Log.w(TAG, "retry back failed", e)
            }
        }, 900L)
    }

    // ------------------------------------------------------------------ 捕捉模式

    /** 显示悬浮按钮。期间服务暂停一切自动点击，免得你要抓的广告被先跳过了。 */
    fun startCapture() {
        if (capturing) return
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(Color.argb(235, 14, 107, 115))
                setPadding(dp(14), dp(10), dp(8), dp(10))
            }
            box.addView(TextView(this).apply {
                text = "捕捉当前界面"
                setTextColor(Color.WHITE)
                textSize = 14f
                setOnClickListener { doCapture() }
            })
            box.addView(TextView(this).apply {
                text = "  ✕  "
                setTextColor(Color.WHITE)
                textSize = 14f
                setOnClickListener { stopCapture() }
            })
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                x = dp(8)
            }
            wm.addView(box, lp)
            captureView = box
        } catch (e: Throwable) {
            Log.w(TAG, "start capture failed", e)
            Toast.makeText(this, "无法显示捕捉按钮", Toast.LENGTH_SHORT).show()
        }
    }

    fun stopCapture() {
        val v = captureView ?: return
        captureView = null
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: Throwable) {
            // 视图已经不在窗口里，忽略
        }
    }

    private fun doCapture() {
        try {
            val root = rootInActiveWindow
            val pkg = root?.packageName?.toString()
            if (root == null || pkg == null || pkg == packageName) {
                safeRecycle(root)
                Toast.makeText(this, "没读到前台界面，请先切到目标应用再点", Toast.LENGTH_SHORT).show()
                return
            }
            val dm = resources.displayMetrics
            val items = ArrayList<CapItem>()
            var visited = 0

            fun walk(n: AccessibilityNodeInfo, depth: Int) {
                if (++visited > CAPTURE_MAX_NODES || depth > MAX_DEPTH) return
                if (n.isVisibleToUser) {
                    val r = Rect()
                    n.getBoundsInScreen(r)
                    val text = n.text?.toString().orEmpty()
                    val desc = n.contentDescription?.toString().orEmpty()
                    val id = n.viewIdResourceName.orEmpty()
                    val hasInfo = text.isNotBlank() || desc.isNotBlank() || id.isNotEmpty()
                    // 整屏大小的容器没法当规则目标，排除
                    val notHuge = r.width() < dm.widthPixels * 0.9 || r.height() < dm.heightPixels * 0.5
                    if (!r.isEmpty && hasInfo && notHuge) {
                        items.add(
                            CapItem(
                                text.take(60), desc.take(60), id, r,
                                n.isClickable, n.className?.toString().orEmpty()
                            )
                        )
                    }
                }
                for (i in 0 until n.childCount) {
                    val c = n.getChild(i) ?: continue
                    walk(c, depth + 1)
                    safeRecycle(c)
                }
            }

            walk(root, 0)
            safeRecycle(root)
            CaptureStore.snapshot = Snapshot(pkg, currentClass, dm.widthPixels, dm.heightPixels, items)
            stopCapture()
            startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Throwable) {
            Log.w(TAG, "capture failed", e)
            Toast.makeText(this, "捕捉失败，请重试", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ 环境信息

    private fun isExcluded(pkg: String) = pkg in Prefs.excluded(this)

    private fun isRedirectTarget(pkg: String): Boolean = pkg in Rules.JUMP_TARGETS

    /** 纯第三方应用：不是系统应用，也不是被更新过的系统应用（Google Play 服务、小米智能服务等都不算）。 */
    private fun isUserApp(pkg: String): Boolean = try {
        (packageManager.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_SYSTEM) == 0
    } catch (e: PackageManager.NameNotFoundException) {
        false // 看不到的包一律按系统组件处理
    }

    @Suppress("DEPRECATION")
    private fun refreshEnv() {
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            homes = packageManager.queryIntentActivities(home, 0)
                .map { it.activityInfo.packageName }
                .toSet()
        } catch (e: Throwable) {
            Log.w(TAG, "query launchers failed", e)
        }
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imes = imm.enabledInputMethodList.map { it.packageName }.toSet()
        } catch (e: Throwable) {
            Log.w(TAG, "query IMEs failed", e)
        }
        userAppCache.clear()
        envAt = SystemClock.elapsedRealtime()
    }

    @Suppress("DEPRECATION")
    private fun safeRecycle(n: AccessibilityNodeInfo?) {
        try {
            n?.recycle() // Android 13+ 已是空操作；旧版本回收到对象池
        } catch (e: Throwable) {
            // 已被回收过，忽略
        }
    }
}
