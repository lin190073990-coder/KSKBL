package com.qingping.adblock

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * “不再点这个”名单：只屏蔽某个应用里的某一个控件 / 某一种弹窗 / 某一个自动返回的目标，
 * 不影响该应用里的其他广告。签名（sig）的写法：
 *   text:<规范化文字>   desc:<规范化描述>   id:<控件 ID 末段>
 *   ocr:<规范化文字>    redirect:<跳转目标的包名或类名>
 */
object BlockStore {
    private const val FILE = "qingping_blocks"
    private const val KEY = "blocks"

    data class Entry(val pkg: String, val sig: String)

    @Volatile
    private var cache: Set<Entry>? = null

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    @Synchronized
    private fun load(c: Context): Set<Entry> {
        cache?.let { return it }
        val out = LinkedHashSet<Entry>()
        try {
            val raw = sp(c).getString(KEY, null)
            if (!raw.isNullOrBlank()) {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val pkg = o.optString("pkg")
                    val sig = o.optString("sig")
                    if (pkg.isNotEmpty() && sig.isNotEmpty()) out.add(Entry(pkg, sig))
                }
            }
        } catch (e: Exception) {
            // 存储损坏就当没有
        }
        cache = out
        return out
    }

    @Synchronized
    private fun save(c: Context, set: Set<Entry>) {
        val arr = JSONArray()
        for (e in set) arr.put(JSONObject().put("pkg", e.pkg).put("sig", e.sig))
        sp(c).edit().putString(KEY, arr.toString()).apply()
        cache = LinkedHashSet(set)
    }

    fun isBlocked(c: Context, pkg: String, sig: String): Boolean = Entry(pkg, sig) in load(c)

    fun all(c: Context): List<Entry> = load(c).toList()

    fun add(c: Context, pkg: String, sig: String) {
        val cur = LinkedHashSet(load(c))
        if (cur.add(Entry(pkg, sig))) save(c, cur)
    }

    fun remove(c: Context, pkg: String, sig: String) {
        val cur = LinkedHashSet(load(c))
        if (cur.remove(Entry(pkg, sig))) save(c, cur)
    }

    /** 给人看的描述。 */
    fun describe(sig: String): String {
        val i = sig.indexOf(':')
        if (i <= 0) return sig
        val v = sig.substring(i + 1)
        return when (sig.substring(0, i)) {
            "text" -> "文字「$v」"
            "desc" -> "描述「$v」"
            "id" -> "控件 ID $v"
            "ocr" -> "OCR 识别的「$v」"
            "redirect" -> "自动返回（目标 $v）"
            "rule" -> "规则 $v"
            else -> sig
        }
    }
}
