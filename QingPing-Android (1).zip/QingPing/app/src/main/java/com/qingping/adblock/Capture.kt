package com.qingping.adblock

import android.graphics.Rect
import java.util.Locale

/** 捕捉模式下，从前台界面抓到的一个控件。 */
data class CapItem(
    val text: String,
    val desc: String,
    val id: String,
    val bounds: Rect,
    val clickable: Boolean,
    val cls: String
) {
    fun title(): String = when {
        text.isNotBlank() -> text
        desc.isNotBlank() -> desc
        else -> id.substringAfterLast('/')
    }

    /** 看起来像“跳过 / 关闭”的排在前面。 */
    fun looksLikeTarget(): Boolean {
        val s = (text + " " + desc + " " + id.substringAfterLast('/')).lowercase()
        return listOf("跳过", "跳過", "skip", "关闭", "close", "×", "✕", "dismiss").any { s.contains(it) }
    }

    /** 推荐的规则写法：有 ID 用 ID，否则用文字（含数字的倒计时文字改成正则），都没有返回 null。 */
    fun suggestRule(): Pair<String, String>? {
        if (id.isNotEmpty()) return RuleStore.KIND_ID to id
        val t = (if (text.isNotBlank()) text else desc).trim()
        if (t.isEmpty()) return null
        if (t.any { it.isDigit() }) {
            val pattern = t.split(Regex("\\d+")).joinToString("\\d+") { Regex.escape(it) }
            return RuleStore.KIND_REGEX to pattern
        }
        return RuleStore.KIND_TEXT to t
    }

    fun xyValue(width: Int, height: Int): String =
        String.format(
            Locale.US, "%.3f,%.3f",
            (bounds.exactCenterX() / width).coerceIn(0f, 1f),
            (bounds.exactCenterY() / height).coerceIn(0f, 1f)
        )
}

class Snapshot(
    val pkg: String,
    val activity: String?,
    val width: Int,
    val height: Int,
    val items: List<CapItem>
)

/** 服务抓完界面后放在这里，CaptureActivity 来取。只在内存里，不落盘。 */
object CaptureStore {
    @Volatile
    var snapshot: Snapshot? = null
}
