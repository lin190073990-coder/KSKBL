package com.qingping.adblock

import android.content.Context
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/**
 * 规则的两个高级选项的输入控件，手动添加 / 捕捉后保存 / 编辑规则时共用：
 *  - 条件：界面里同时出现这段文字时才点（比如出现“青少年模式”时才点“我知道了”）；
 *  - 后续步骤：第一下点成功后，再依次点最多 3 个目标（比如点“×”之后再点“不感兴趣”）。
 */
class RuleExtras(ctx: Context, whenInit: String = "", stepsInit: String = "") {
    private val density = ctx.resources.displayMetrics.density

    private val title = TextView(ctx).apply {
        text = "高级选项（可留空）"
        textSize = 13f
        alpha = 0.7f
        setPadding(0, (12 * density).toInt(), 0, 0)
    }

    private val whenEdit = EditText(ctx).apply {
        hint = "条件：界面里同时出现这段文字才点"
        setSingleLine()
        setText(whenInit)
    }

    private val stepsEdit = EditText(ctx).apply {
        hint = "后续步骤，每行一步，最多 3 步。例：\n文字:不感兴趣\n控件ID:com.xx:id/btn_ok\n坐标:0.5,0.9"
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        minLines = 3
        gravity = Gravity.TOP or Gravity.START
        setText(stepsInit)
    }

    fun addTo(box: LinearLayout) {
        box.addView(title)
        box.addView(whenEdit)
        box.addView(stepsEdit)
    }

    fun whenText(): String = whenEdit.text.toString().trim()

    /** null = 写法不对。 */
    fun steps(): List<RuleStore.Step>? = RuleStore.parseSteps(stepsEdit.text.toString())

    companion object {
        const val STEPS_ERROR =
            "后续步骤的写法不对：每行“类型:内容”，类型可写 文字 / 正则 / 控件ID / 坐标，最多 3 行"
    }
}
