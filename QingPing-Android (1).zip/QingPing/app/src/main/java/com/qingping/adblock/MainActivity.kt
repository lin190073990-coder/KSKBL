package com.qingping.adblock

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private companion object {
        const val RANGE_TODAY = 0
        const val RANGE_WEEK = 1
        const val RANGE_ALL = 2
    }

    private lateinit var tvStatus: TextView
    private lateinit var tvHint: TextView
    private lateinit var btnEnable: TextView
    private lateinit var tvRangeLabel: TextView
    private lateinit var tvHeroCount: TextView
    private lateinit var tvBreakdown: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var list: LinearLayout
    private lateinit var btnPause: TextView
    private lateinit var tvPauseInfo: TextView
    private lateinit var btnOcrApps: TextView
    private var range = RANGE_TODAY

    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvHint = findViewById(R.id.tvHint)
        btnEnable = findViewById(R.id.btnEnable)
        tvRangeLabel = findViewById(R.id.tvRangeLabel)
        tvHeroCount = findViewById(R.id.tvHeroCount)
        tvBreakdown = findViewById(R.id.tvBreakdown)
        tvEmpty = findViewById(R.id.tvEmpty)
        list = findViewById(R.id.list)

        btnPause = findViewById(R.id.btnPause)
        tvPauseInfo = findViewById(R.id.tvPauseInfo)
        btnOcrApps = findViewById(R.id.btnOcrApps)

        btnEnable.setOnClickListener { onEnableClick() }
        btnPause.setOnClickListener { onPauseClick() }
        btnOcrApps.setOnClickListener { showOcrApps() }
        findViewById<View>(R.id.btnHelp).setOnClickListener { showHelp() }
        findViewById<View>(R.id.btnKeepAlive).setOnClickListener { showKeepAlive() }
        findViewById<View>(R.id.btnRules).setOnClickListener {
            startActivity(Intent(this, RulesActivity::class.java))
        }

        findViewById<MaterialSwitch>(R.id.swSkip).apply {
            isChecked = Prefs.skipSplash(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setSkipSplash(this@MainActivity, on) }
        }
        findViewById<MaterialSwitch>(R.id.swPopup).apply {
            isChecked = Prefs.popupClose(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setPopupClose(this@MainActivity, on) }
        }
        findViewById<MaterialSwitch>(R.id.swRedirect).apply {
            isChecked = Prefs.blockRedirect(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setBlockRedirect(this@MainActivity, on) }
        }
        findViewById<MaterialSwitch>(R.id.swSafe).apply {
            isChecked = Prefs.safeMode(this@MainActivity)
            setOnCheckedChangeListener { btn, on ->
                if (on) {
                    Prefs.setSafeMode(this@MainActivity, true)
                } else {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("关闭安全保护？")
                        .setMessage("关闭后，清屏可能会在密码输入界面、银行和支付类应用里自动点击或返回。确定要关闭吗？")
                        .setPositiveButton("关闭保护") { _, _ -> Prefs.setSafeMode(this@MainActivity, false) }
                        .setNegativeButton("保持开启") { _, _ -> btn.isChecked = true }
                        .setOnCancelListener { btn.isChecked = true }
                        .show()
                }
            }
        }
        setupOcrSwitch()

        findViewById<MaterialButtonToggleGroup>(R.id.toggleRange).apply {
            check(R.id.btnToday)
            addOnButtonCheckedListener { _, id, checked ->
                if (checked) {
                    range = when (id) {
                        R.id.btnToday -> RANGE_TODAY
                        R.id.btnWeek -> RANGE_WEEK
                        else -> RANGE_ALL
                    }
                    loadStats()
                }
            }
        }

        StatsStore.prune(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        Guard.ensureAlive(this, notify = false) // 被强行停止后，打开一次清屏就能自愈（需 ADB 授权）
        refreshStatus()
        refreshPause()
        refreshOcrButton()
        loadStats()
        window.decorView.postDelayed({ if (!isDestroyed) refreshStatus() }, 1000)
    }

    // ------------------------------------------------------------------ 暂停

    private fun onPauseClick() {
        if (Prefs.isPaused(this)) {
            Prefs.resume(this)
            refreshPause()
            return
        }
        val items = arrayOf("30 分钟", "2 小时", "直到我手动恢复")
        val durations = longArrayOf(30 * 60_000L, 2 * 3_600_000L, 365L * 24 * 3_600_000L)
        AlertDialog.Builder(this)
            .setTitle("暂停多久？")
            .setItems(items) { _, i ->
                Prefs.pauseFor(this, durations[i])
                refreshPause()
            }
            .show()
    }

    private fun refreshPause() {
        if (Prefs.isPaused(this)) {
            val ms = Prefs.pausedUntil(this) - System.currentTimeMillis()
            btnPause.text = "恢复清屏"
            tvPauseInfo.text = if (ms > 30L * 24 * 3_600_000L) {
                "已暂停，直到你手动恢复。"
            } else {
                "已暂停，约 ${ms / 60_000L + 1} 分钟后自动恢复。"
            }
        } else {
            btnPause.text = "暂停清屏…"
            tvPauseInfo.text = "临时停用全部自动点击，到时间自动恢复。下拉通知栏的“暂停清屏”开关效果相同。"
        }
    }

    // ------------------------------------------------------------------ OCR

    private fun setupOcrSwitch() {
        val sw = findViewById<MaterialSwitch>(R.id.swOcr)
        val desc = findViewById<TextView>(R.id.tvOcrDesc)
        if (!OcrEngine.available) {
            sw.isChecked = false
            sw.isEnabled = false
            btnOcrApps.visibility = View.GONE
            desc.text = "当前安装的是 lite 版，不含此功能。想用请安装 full 版（安装包更大，且识别组件 ML Kit 可能带入联网权限）。"
            return
        }
        desc.text = "对游戏、H5、自绘开屏这类读不到控件的界面：截屏后在本机识别文字，再点“跳过”。" +
            "更耗电，所以只对你选的应用、打开后 6 秒内运行；需要 Android 11 及以上。" +
            "截图只在内存里处理，不保存、不上传。识别组件 ML Kit 可能让安装包带上联网权限，清屏自己的代码不联网。"
        sw.isChecked = Prefs.ocrEnabled(this)
        sw.setOnCheckedChangeListener { btn, on ->
            if (!on) {
                Prefs.setOcrEnabled(this, false)
            } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                Toast.makeText(this, "OCR 需要 Android 11 及以上", Toast.LENGTH_LONG).show()
                btn.isChecked = false
            } else {
                Prefs.setOcrEnabled(this, true)
                if (Prefs.ocrApps(this).isEmpty()) showOcrApps()
            }
        }
    }

    private fun refreshOcrButton() {
        btnOcrApps.text = "选择启用 OCR 的应用（已选 ${Prefs.ocrApps(this).size} 个）"
    }

    @Suppress("DEPRECATION")
    private fun showOcrApps() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second }
        val chosen = Prefs.ocrApps(this)
        val checked = BooleanArray(apps.size) { apps[it].first in chosen }
        AlertDialog.Builder(this)
            .setTitle("哪些应用启用 OCR")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton("保存") { _, _ ->
                val visible = apps.map { it.first }.toSet()
                val result = HashSet<String>(chosen.filter { it !in visible }) // 看不到的包保持原样
                apps.forEachIndexed { i, a -> if (checked[i]) result.add(a.first) }
                Prefs.setOcrApps(this, result)
                refreshOcrButton()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // ------------------------------------------------------------------ 状态

    private fun refreshStatus() {
        val running = AdSkipService.instance != null
        val enabled = Guard.isEnabledInSettings(this)

        val (text, color) = when {
            running -> "● 无障碍服务运行中" to R.color.status_on
            enabled -> "● 已开启，正在等待系统连接服务" to R.color.status_wait
            else -> "● 无障碍服务未开启，目前不会拦截任何广告" to R.color.status_off
        }
        tvStatus.text = text
        tvStatus.setTextColor(getColor(color))
        btnEnable.text = if (running) "管理服务" else "开启服务"

        tvHint.text = buildString {
            if (Build.VERSION.SDK_INT >= 33 && !running) {
                append("Android 13 及以上侧载安装的应用，开关可能是灰色的：先在应用详情页右上角菜单里选“允许受限制的设置”，再回来开启。\n")
            }
            append(
                if (Guard.canWriteSecureSettings(this@MainActivity)) {
                    "已授予自愈权限：服务被系统关闭后，清屏会自己重新开启。想暂停清屏，点上面的“暂停清屏”，或关掉功能开关。"
                } else {
                    "想让服务被关闭后自动恢复？在“保活设置”里查看 ADB 授权方法。"
                }
            )
        }
    }

    private fun onEnableClick() {
        val already = AdSkipService.instance != null || Guard.isEnabledInSettings(this)
        if (!already && Guard.tryEnableSelf(this)) {
            Toast.makeText(this, "已自动开启无障碍服务", Toast.LENGTH_SHORT).show()
            window.decorView.postDelayed({ if (!isDestroyed) refreshStatus() }, 1000)
        } else {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    // ------------------------------------------------------------------ 统计

    private fun rangeLabel() = when (range) {
        RANGE_TODAY -> "今日已清除"
        RANGE_WEEK -> "近 7 天已清除"
        else -> "累计已清除"
    }

    private fun loadStats() {
        val since = when (range) {
            RANGE_TODAY -> StatsStore.startOfToday()
            RANGE_WEEK -> System.currentTimeMillis() - 7L * 24 * 3600 * 1000
            else -> 0L
        }
        StatsStore.loadStats(this, since) { render(it) }
    }

    private fun render(stats: List<AppStat>) {
        if (isDestroyed) return
        val splash = stats.sumOf { it.splash }
        val redirect = stats.sumOf { it.redirect }
        val popup = stats.sumOf { it.popup }
        tvRangeLabel.text = rangeLabel()
        tvHeroCount.text = (splash + redirect + popup).toString()
        tvBreakdown.text = "开屏跳过 $splash 次，弹窗与规则 $popup 次，跳转返回 $redirect 次"

        list.removeAllViews()
        tvEmpty.visibility = if (stats.isEmpty()) View.VISIBLE else View.GONE

        val paused = Prefs.excluded(this)
        val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
        for (st in stats) {
            val row = layoutInflater.inflate(R.layout.item_app, list, false)
            val (label, icon) = labelAndIcon(st.pkg)
            row.findViewById<TextView>(R.id.tvName).text =
                if (st.pkg in paused) "$label（已暂停）" else label
            row.findViewById<TextView>(R.id.tvDetail).text =
                "开屏 ${st.splash}，弹窗/规则 ${st.popup}，返回 ${st.redirect}，最近 ${fmt.format(Date(st.lastTs))}"
            row.findViewById<TextView>(R.id.tvCount).text = st.total.toString()
            row.findViewById<ImageView>(R.id.ivIcon).setImageDrawable(icon)
            row.setOnClickListener { showDetail(st.pkg, label) }
            list.addView(row)
        }
    }

    private fun labelAndIcon(pkg: String): Pair<String, Drawable?> = try {
        val ai = packageManager.getApplicationInfo(pkg, 0)
        packageManager.getApplicationLabel(ai).toString() to packageManager.getApplicationIcon(ai)
    } catch (e: Exception) {
        pkg to null // 应用已卸载，显示包名
    }

    private fun kindName(type: Int) = when (type) {
        StatsStore.TYPE_SPLASH -> "跳过"
        StatsStore.TYPE_REDIRECT -> "返回"
        StatsStore.TYPE_POPUP -> "关弹窗"
        else -> "规则"
    }

    private fun showDetail(pkg: String, label: String) {
        StatsStore.loadRecent(this, pkg, 25) { rows ->
            if (isDestroyed) return@loadRecent
            val fmt = SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault())
            val paused = pkg in Prefs.excluded(this)
            val b = AlertDialog.Builder(this)
            if (rows.isEmpty()) {
                b.setTitle(label).setMessage("还没有记录")
            } else {
                b.setTitle("$label · 点一条记录可屏蔽")
                val lines = rows.map { "${fmt.format(Date(it.ts))}  ${kindName(it.type)}  ${it.detail}" }
                b.setItems(lines.toTypedArray()) { _, i -> askBlock(pkg, label, rows[i]) }
            }
            b.setPositiveButton("关闭", null)
                .setNeutralButton(if (paused) "恢复对此应用的拦截" else "暂停对此应用的拦截") { _, _ ->
                    Prefs.setExcluded(this, pkg, !paused)
                    loadStats()
                }
                .show()
        }
    }

    /** “不再点这个”：只屏蔽那一个控件 / 那一种弹窗 / 那一个自动返回的目标，不影响其他广告。 */
    private fun askBlock(pkg: String, label: String, row: EventRow) {
        if (row.sig.isEmpty()) {
            Toast.makeText(this, "这是旧版本留下的记录，没有可屏蔽的信息", Toast.LENGTH_LONG).show()
            return
        }
        val isRule = row.sig.startsWith("rule:")
        val what = if (isRule) row.detail else BlockStore.describe(row.sig)
        val tail = if (isRule) {
            "规则只是被停用，可以在“我的规则”里重新打开。"
        } else {
            "只屏蔽这一个，该应用里的其他广告照常拦截。可以在“我的规则 → 已屏蔽的控件”里恢复。"
        }
        AlertDialog.Builder(this)
            .setTitle(if (isRule) "停用这条规则？" else "不再点这个？")
            .setMessage("$label\n$what\n\n$tail")
            .setPositiveButton(if (isRule) "停用" else "不再点") { _, _ ->
                if (isRule) {
                    RuleStore.setEnabled(this, row.sig.removePrefix("rule:"), false)
                } else {
                    BlockStore.add(this, pkg, row.sig)
                }
                Toast.makeText(this, if (isRule) "已停用" else "已屏蔽", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // ------------------------------------------------------------------ 使用说明

    private fun showHelp() {
        val text = "清屏怎么工作\n" +
            "靠系统的“无障碍服务”读取前台界面，发现广告上的按钮后替你点一下。广告出现之后才处理，所以有时会闪现不到一秒。\n\n" +
            "功能开关\n" +
            "• 跳过开屏广告：应用打开后 7 秒内找“跳过”。\n" +
            "• 关闭弹窗广告：只处理第三方应用，系统应用不动。\n" +
            "• 误触跳转返回：只针对已知的广告落地应用（浏览器、应用商店、常见电商 App）。\n" +
            "• 安全保护：密码界面、银行 / 支付类应用一律不点。\n" +
            "• OCR：读不到控件的界面（游戏、H5）截屏识别，默认关闭，只对你选的应用。\n\n" +
            "暂停\n" +
            "首页的“暂停清屏”，或下拉通知栏里的“暂停清屏”开关。下拉通知栏 → 编辑（铅笔图标）→ 把“清屏捕捉”“清屏暂停”拖到面板里。\n\n" +
            "误点了怎么办\n" +
            "在首页统计里点开那个应用，点那条记录，选“不再点这个”。只屏蔽那一个控件，其他广告照常拦截。屏蔽错了可在“我的规则”里恢复。\n\n" +
            "清屏认不出的广告\n" +
            "“我的规则 → 捕捉界面”，广告出现时点悬浮按钮，选中“跳过 / 关闭”那一项就生成规则。点已有规则还能加“条件”和“后续步骤”：" +
            "条件是界面出现某段文字才点；后续步骤是点完第一下再依次点最多 3 个目标，比如先点“×”再点“不感兴趣”。\n\n" +
            "隐私\n" +
            "所有处理都在本机完成，清屏自己的代码不联网、不上传。"
        AlertDialog.Builder(this)
            .setTitle("使用说明")
            .setMessage(text)
            .setPositiveButton("知道了", null)
            .show()
    }

    // ------------------------------------------------------------------ 保活

    private fun showKeepAlive() {
        val items = arrayOf(
            "忽略电池优化",
            "自启动与后台运行管理（各厂商页面）",
            "应用详情页（含“允许受限制的设置”）",
            "ADB 自愈授权命令",
            "防止被一键清理的做法"
        )
        AlertDialog.Builder(this)
            .setTitle("保活设置")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> Guard.openBatterySettings(this)
                    1 -> Guard.openAutoStart(this)
                    2 -> Guard.openAppDetails(this)
                    3 -> showAdbCommand()
                    else -> showCleanTips()
                }
            }
            .show()
    }

    private fun showAdbCommand() {
        val cmd = "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"
        AlertDialog.Builder(this)
            .setTitle("授权自愈（可选）")
            .setMessage(
                "手机开启 USB 调试并连接电脑，执行一次：\n\n$cmd\n\n" +
                    "授权后，开机或被系统关闭无障碍时，清屏会自动重新开启，也不用再手动去系统设置里勾选。" +
                    "想暂停清屏，请用应用内的“暂停清屏”或关掉功能开关，而不是系统里的无障碍开关。"
            )
            .setPositiveButton("复制命令") { _, _ ->
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("adb", cmd))
                Toast.makeText(this, "已复制", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("关闭", null)
            .show()
    }

    private fun showCleanTips() {
        AlertDialog.Builder(this)
            .setTitle("防止被一键清理")
            .setMessage(
                "在最近任务里长按（或下拉）清屏的卡片，选“锁定”。\n\n" +
                    "把清屏加进系统后台管理或一键清理的白名单。\n\n" +
                    "不要在应用详情页点“强行停止”：系统会直接把无障碍服务从已开启列表里移除，应用自己拦不住。\n\n" +
                    "如果已经被强行停止：重新打开一次清屏。授予过 ADB 自愈权限的话，它会自己把服务开回来。"
            )
            .setPositiveButton("知道了", null)
            .show()
    }
}
