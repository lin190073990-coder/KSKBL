package com.qingping.adblock

import android.content.DialogInterface
import android.os.Bundle
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** 展示捕捉到的控件，点一个就能生成规则。 */
class CaptureActivity : AppCompatActivity() {

    private var snap: Snapshot? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val s = CaptureStore.snapshot
        if (s == null) {
            finish()
            return
        }
        snap = s
        setContentView(R.layout.activity_capture)

        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(s.pkg, 0)).toString()
        } catch (e: Exception) {
            s.pkg
        }
        findViewById<TextView>(R.id.tvTitle).text = "捕捉到 ${s.items.size} 个控件"
        findViewById<TextView>(R.id.tvSub).text =
            "$label（${s.pkg}）\n界面：${s.activity ?: "未知"}\n点要自动点击的那一项（通常是“跳过”或关闭按钮），排在前面的更像目标。"

        val list = findViewById<LinearLayout>(R.id.list)
        val sorted = s.items.sortedWith(
            compareBy<CapItem>(
                { if (it.looksLikeTarget()) 0 else 1 },
                { it.bounds.width().toLong() * it.bounds.height() }
            )
        )
        for (item in sorted) {
            val row = layoutInflater.inflate(R.layout.item_node, list, false)
            row.findViewById<TextView>(R.id.tvName).text = item.title()
            row.findViewById<TextView>(R.id.tvDetail).text = buildString {
                if (item.id.isNotEmpty()) append(item.id.substringAfterLast('/')).append("  ")
                append(item.cls.substringAfterLast('.'))
                if (item.clickable) append("  可点击")
                append("  ${item.bounds.width()}×${item.bounds.height()}")
            }
            row.setOnClickListener { confirm(s, label, item) }
            list.addView(row)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun confirm(s: Snapshot, label: String, item: CapItem) {
        val suggestion = item.suggestRule()
        val kindName = when (suggestion?.first) {
            RuleStore.KIND_ID -> "控件 ID"
            RuleStore.KIND_REGEX -> "文字（数字部分自动适配）"
            RuleStore.KIND_TEXT -> "文字"
            else -> "坐标"
        }
        val xy = item.xyValue(s.width, s.height)
        val rule = suggestion ?: (RuleStore.KIND_XY to xy)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        box.addView(TextView(this).apply {
            text = "方式：$kindName\n内容：${rule.second}"
            textSize = 14f
        })
        val only = CheckBox(this).apply {
            text = "只在这个界面生效（推荐）"
            isChecked = s.activity != null
            isEnabled = s.activity != null
        }
        box.addView(only)
        val extras = RuleExtras(this)
        extras.addTo(box)
        val sv = ScrollView(this).apply { addView(box) }

        /** 保存成功返回 true；后续步骤写法不对时提示并返回 false（对话框保持打开）。 */
        fun trySave(kind: String, value: String): Boolean {
            val steps = extras.steps()
            if (steps == null) {
                Toast.makeText(this, RuleExtras.STEPS_ERROR, Toast.LENGTH_LONG).show()
                return false
            }
            val activity = if (only.isChecked) s.activity.orEmpty() else ""
            val added = RuleStore.add(
                this,
                RuleStore.Rule(RuleStore.newId(), s.pkg, activity, kind, value, "", true, extras.whenText(), steps)
            )
            Toast.makeText(
                this,
                if (added) "已保存，下次进入这个界面会自动点" else "已经有相同的规则了",
                Toast.LENGTH_LONG
            ).show()
            finish()
            return true
        }

        val b = AlertDialog.Builder(this)
            .setTitle("为 $label 添加规则")
            .setView(sv)
            .setPositiveButton("保存", null)
            .setNegativeButton("取消", null)
        if (suggestion != null) b.setNeutralButton("改用坐标", null)
        val dlg = b.create()
        dlg.setOnShowListener {
            dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                if (trySave(rule.first, rule.second)) dlg.dismiss()
            }
            dlg.getButton(DialogInterface.BUTTON_NEUTRAL)?.setOnClickListener {
                if (trySave(RuleStore.KIND_XY, xy)) dlg.dismiss()
            }
        }
        dlg.show()
    }

    override fun onDestroy() {
        if (isFinishing) CaptureStore.snapshot = null
        super.onDestroy()
    }
}
